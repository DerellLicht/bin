//  This module, which has been entirely compiled from public-domain sources, 
//  is itself declared in the public domain.

//  not in MinGW include file
#define WM_UAHINITMENU           147
#define WM_UAHMEASUREMENUITEM    148

char *lookup_winmsg_name(int msg_code);

