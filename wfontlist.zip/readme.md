### wFontList - display all installed fonts

This application is copyright (c) 2009-2017  Daniel D Miller  
This program, and its source code, are distributed as unrestricted freeware.
You can use them for any purpose, personal or commercial, in whole or in part,
for any purpose that you wish, without contacting me further.

Obtain [source code](https://github.com/DerellLicht/wFontList) here

Download [Windows installer](https://github.com/DerellLicht/bin/raw/master/winagrams.setup.exe) here
